<div id="layoutSidenav_content">
                <main>
                <div class="container-fluid">
                        <h1 class="mt-4">Manage After Zip</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Manage After Zip</li>
                        </ol>
                        
                        <div class="card mb-4">
                            
                            <div class="card-body">
                                <h3>After Zip1</h3>
                                <div class="table-responsive">
                                    <table class="table table-bordered"  width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                               <th>S.No</th>
                                                <th>Zip1</th>
                                                <th>Delete</th>
                                            </tr>
                                        </thead>
                                       
                                        <tbody>
                                            <?php
                                                if(!empty($product->azip1)){
                                                    $azip1Arr = explode(",", $product->azip1);
                                                    for($i = 0; $i < count($azip1Arr); $i++){
                                            ?>
                                                      <tr>
                                                        <td><?=$i+1?></td>
                                                        <td><a href = "<?=base_url()?>upload/AfterZip/<?=$azip1Arr[$i]?>" target = "_blank">View</a></li></td>
                                                        <td><a href = "<?=base_url()?>AdminController/deletea1zip/<?=$product->id?>/<?=$azip1Arr[$i]?>">Delete</a>
                                                      </tr>
                                            <?php
                                                    }
                                            ?>


                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                       
                                    </table>
                                </div>


                                <h3>After Zip2</h3>
                                <div class="table-responsive">
                                    <table class="table table-bordered"  width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                               <th>S.No</th>
                                                <th>Zip2</th>
                                                <th>Delete</th>
                                            </tr>
                                        </thead>
                                       
                                        <tbody>
                                            <?php
                                                if(!empty($product->azip2)){
                                                    $azip2Arr = explode(",", $product->azip2);
                                                    for($i = 0; $i < count($azip2Arr); $i++){
                                            ?>
                                                     <tr>
                                                        <td><?=$i+1?></td>
                                                        <td><a href = "<?=base_url()?>upload/AfterZip/<?=$azip2Arr[$i]?>" target = "_blank">View</a></li></td>
                                                        <td><a href = "<?=base_url()?>AdminController/deletea2zip/<?=$product->id?>/<?=$azip2Arr[$i]?>">Delete</a>
                                                     </tr>
                                            <?php
                                                    }
                                            ?>


                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                       
                                    </table>
                                </div>


                                <h3>After Zip3</h3>
                                <div class="table-responsive">
                                    <table class="table table-bordered"  width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                               <th>S.No</th>
                                                <th>Zip3</th>
                                                <th>Delete</th>
                                            </tr>
                                        </thead>
                                       
                                        <tbody>
                                            <?php
                                                if(!empty($product->azip3)){
                                                    $azip3Arr = explode(",", $product->azip3);
                                                    for($i = 0; $i < count($azip3Arr); $i++){
                                            ?>
                                                      <tr>
                                                        <td><?=$i+1?></td>
                                                        <td><a href = "<?=base_url()?>upload/AfterZip/<?=$azip3Arr[$i]?>" target = "_blank">View</a></li></td>
                                                        <td><a href = "<?=base_url()?>AdminController/deletea3zip/<?=$product->id?>/<?=$azip3Arr[$i]?>">Delete</a>
                                                     </tr>
                                            <?php
                                                    }
                                            ?>


                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                       
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
