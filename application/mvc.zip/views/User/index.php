
           <div id="layoutSidenav_content">
           <main>
                    
                   
                    <div class="container">
                        <h1 class="mt-3 mb-5">Profile</h1>
                        
                          <div>
							  <table class = "table">
									<tr>
										<th>Name</th>
										<td><?=$profile->name?></td>
									</tr>

									<tr>
										<th>Email</th>
										<td><?=$profile->email?></td>
									</tr>

									<tr>
										<th>Mobile No.</th>
										<td><?=$profile->mobile?></td>
									</tr>
							  </table>
						  </div>
                        
                        
                            
                        
                    </div>
                </main>
                            