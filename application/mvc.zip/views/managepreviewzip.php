<div id="layoutSidenav_content">
                <main>
                <div class="container-fluid">
                        <h1 class="mt-4">Manage Preview Zip</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Manage Preview Zip</li>
                        </ol>
                        
                        <div class="card mb-4">
                            
                            <div class="card-body">
                                <h3>Preview Zip1</h3>
                                <div class="table-responsive">
                                    <table class="table table-bordered"  width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                               <th>S.No</th>
                                                <th>Zip1</th>
                                                <th>Delete</th>
                                            </tr>
                                        </thead>
                                       
                                        <tbody>
                                            <?php
                                                if(!empty($product->pzip1)){
                                                    $pzip1Arr = explode(",", $product->pzip1);
                                                    for($i = 0; $i < count($pzip1Arr); $i++){
                                            ?>
                                                      <tr>
                                                        <td><?=$i+1?></td>
                                                        <td><a href = "<?=base_url()?>upload/PreviewZip/<?=$pzip1Arr[$i]?>" target = "_blank">View</a></li></td>
                                                        <td><a href = "<?=base_url()?>AdminController/deletep1zip/<?=$product->id?>/<?=$pzip1Arr[$i]?>">Delete</a>
                                                      </tr>
                                            <?php
                                                    }
                                            ?>


                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                       
                                    </table>
                                </div>


                                <h3>Preview Zip2</h3>
                                <div class="table-responsive">
                                    <table class="table table-bordered"  width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                               <th>S.No</th>
                                                <th>Zip2</th>
                                                <th>Delete</th>
                                            </tr>
                                        </thead>
                                       
                                        <tbody>
                                            <?php
                                                if(!empty($product->pzip2)){
                                                    $pzip2Arr = explode(",", $product->pzip2);
                                                    for($i = 0; $i < count($pzip2Arr); $i++){
                                            ?>
                                                      <tr>
                                                        <td><?=$i+1?></td>
                                                        <td><a href = "<?=base_url()?>upload/PreviewZip/<?=$pzip2Arr[$i]?>" target = "_blank">View</a></li></td>
                                                        <td><a href = "<?=base_url()?>AdminController/deletep2zip/<?=$product->id?>/<?=$pzip2Arr[$i]?>">Delete</a>
                                                      </tr>
                                            <?php
                                                    }
                                            ?>


                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                       
                                    </table>
                                </div>


                                <h3>Preview Zip3</h3>
                                <div class="table-responsive">
                                    <table class="table table-bordered"  width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                               <th>S.No</th>
                                                <th>Zip3</th>
                                                <th>Delete</th>
                                            </tr>
                                        </thead>
                                       
                                        <tbody>
                                            <?php
                                                if(!empty($product->pzip3)){
                                                    $pzip3Arr = explode(",", $product->pzip3);
                                                    for($i = 0; $i < count($pzip3Arr); $i++){
                                            ?>
                                                      <tr>
                                                        <td><?=$i+1?></td>
                                                        <td><a href = "<?=base_url()?>upload/PreviewZip/<?=$pzip3Arr[$i]?>" target = "_blank">View</a></li></td>
                                                        <td><a href = "<?=base_url()?>AdminController/deletep3zip/<?=$product->id?>/<?=$pzip3Arr[$i]?>">Delete</a>
                                                      </tr>
                                            <?php
                                                    }
                                            ?>


                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                       
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
