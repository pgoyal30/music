<?php

    class AdminController extends CI_Controller{
        public function __construct(){
            parent::__construct();
            $this->load->model('AdminModel');
            
        }

		public function index(){
			$this->load->view('login.php');
		}

		public function checklogin(){
			$email = $_POST['email'];
			$password = $_POST['password'];
			$isValid = $this->AdminModel->checklogin($email, $password);
			if(isset($isValid)){
				$_SESSION['id'] = $isValid->id;
				$_SESSION['email'] = $isValid->email;
				$_SESSION['role'] = $isValid->role;
				echo "Yes";
			}else{
				echo "No";
			}
		}


		public function isLogin(){
			if(!isset($_SESSION['id'])  && !isset($_SESSION['email'])){
				redirect(base_url() . "AdminController/index");
			}
		}

		public function logout(){    
			unset($_SESSION['id']);
			unset($_SESSION['email']);
			session_destroy();
			redirect(base_url() . "AdminController/index");
		}


		public function register(){
			$this->load->view('register.php');
		}


		public function checkemail(){
			$email = $this->input->post('user_email');
			$isValid = $this->AdminModel->checkemail($email);
			if(isset($isValid)){
				echo "Yes";
			}else{
				echo "No";
			}
		}
	
		public function insertuserinfo(){
			$data['name'] = $_POST['name'];
			$data['email'] = $_POST['email'];
			$data['mobile'] = $_POST['mobile'];
			$data['password'] = $_POST['password'];
			$data['role'] = 1;
			$response = $this->AdminModel->insertuser($data);
			if(isset($response)){
				echo "Yes";
			}else{
				echo "No";
			}
		}

		public function createcategory(){
			$this->load->view('header.php');
			$this->load->view('create-category.php');
			$this->load->view('footer.php');
		}

		public function create_category(){
			$data['title'] = $this->input->post('title');
			$data['status'] = $this->input->post('status');
			$data['summary'] = $this->input->post('summary');
			$photoex = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
			$url = base_url() . "AdminController/createcategory";
			$extensionArr = array('png', 'jpeg', 'jpg', 'gif');
			if(!in_array($photoex, $extensionArr)){
				echo "<script>alert('Please select only jpeg, png, jpg format only');</script>";
				echo "<script>window.location.href = '{$url}';</script>";
			}else{
				        
				        $photo  = time() .  '' . rand(1,100) . "." . $photoex;
						$data['photo'] = $photo;
						
						$config = array(
							'upload_path' => "./upload/Category/",
							'allowed_types' => "gif|jpg|png|jpeg",
							'file_name' => $photo
							// 'max_size' => '2048000'
						);
						
						$this->load->library('upload', $config);
					

						if(!$this->upload->do_upload('photo')){
							$error = array('error' => $this->upload->display_errors());
							echo "<script>alert('{$error['error']}');</script>";
				            echo "<script>window.location.href = '{$url}';</script>";

						}else{
						
								$data1 = array('upload_data' => $this->upload->data());
								$this->AdminModel->createCategory($data);
								redirect(base_url() . "AdminController/managecategory");
					    }
			}
			
		}

		public function managecategory(){
			$this->isLogin();
            $this->load->view('header');
            $data['category'] = $this->AdminModel->getCategory();
            $this->load->view('manage-category', $data);
            $this->load->view('footer');
        }

		public function editcategory($id){
			$this->isLogin();
			$data['category'] = $this->AdminModel->editCategory($id);
            $this->load->view('header');
            $this->load->view('edit-category', $data);
            $this->load->view('footer');
		}

		public function edit_category($id){
			$this->isLogin();
			$data['title'] = $this->input->post('title');
			$data['summary'] = $this->input->post('summary');
			$data['status'] = $this->input->post('status');
			$oldphoto = $this->input->post('oldphoto');
			$url = base_url() . "AdminController/editcategory/$id";

			if($_FILES['photo']['name'] == ""){
				// $data['resume'] = $oldresume;
					$data['photo'] = $oldphoto;	
			}else{
				
					// $extensionArr = array('png', 'jpeg', 'jpg', 'gif');
					// if(!in_array($photoex, $extensionArr)){
					// 	echo "<script>alert('Please select only jpeg, png, jpg format only');</script>";
					// 	echo "<script>window.location.href = '{$url}';</script>";
					// }else{
						$data['photo'] = $_FILES['photo']['name'];
						
						$photoex = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
						$photo  = time() .  '' . rand(1,100) . "." . $photoex;
						$data['photo'] = $photo;
						$config = array(
						'upload_path' => "./upload/Category/",
						'allowed_types' => "gif|jpg|png|jpeg",
						'file_name' => $photo
						// 'max_size' => '2048000'
						);
						$this->load->library('upload', $config);
						if(!$this->upload->do_upload('photo')){

							$error = array('error' => $this->upload->display_errors());
							echo "<script>alert('{$error['error']}');</script>";
				            echo "<script>window.location.href = '{$url}';</script>";

							die();
						}else{
							if(file_exists('./upload/Category/'.$oldphoto)){
								unlink('./upload/Category/'.$oldphoto);
							}
							$data1 = array('upload_data' => $this->upload->data());
						}
						
				    // }
					
				}
			
	
			$this->AdminModel->updateCategory($id,$data);
			redirect(base_url() . "AdminController/managecategory");
		}

		public function deletecategory($id){
			$this->isLogin();
			$data['category'] = $this->AdminModel->editCategory($id);
			$photo = $data['category']->photo;
			if(file_exists('./upload/Category/'.$photo)){
				unlink('./upload/Category/'.$photo);
			}
			
			$this->AdminModel->deleteCategory($id);
			redirect(base_url() . "AdminController/managecategory");
		}


		public function addproduct(){
			$this->isLogin();
			$data['category'] = $this->AdminModel->getCategory();
			$this->load->view('header.php');
			$this->load->view('add-product', $data);
			$this->load->view('footer.php');
		}

		public function add_product(){
			$this->isLogin();
			$url = base_url() . "AdminController/addproduct";
			$data['title'] = $this->input->post('title');
			$data['catalogno'] = $this->input->post('catalogno');
			$data['track'] = $this->input->post('track');
			$data['description'] = $this->input->post('description');
			$data['categoryid'] = $this->input->post('categoryid');
			$data['usages'] = $this->input->post('usages');
			$data['key'] = $this->input->post('key');
			$data['bpm'] = $this->input->post('bpm');
			$data['price1'] = $this->input->post('price1');
			$data['price2'] = $this->input->post('price2');
			$data['price3'] = $this->input->post('price3');
			$data['discount'] = $this->input->post('discount');
			$data['status'] = $this->input->post('status');
			$data['photo'] = str_replace(' ', '_', $_FILES['photo']['name']);
			// $data['demotrack'] = str_replace(' ', '_', $_FILES['demotrack']['name']);
			
			$config = array(
                'upload_path' => "./upload/Product/",
                'allowed_types' => "gif|jpg|png|jpeg",
                // 'max_size' => '2048000'
            );
		
            $this->load->library('upload', $config);
           

            if(!$this->upload->do_upload('photo')){
				$error = array('error' => $this->upload->display_errors());
				echo "<script>alert('{$error['error']}');</script>";
				echo "<script>window.location.href = '{$url}';</script>";
				die();

            }else{
				
					$data1 = array('upload_data' => $this->upload->data("{$data['photo']}"));
                    $this->AdminModel->addProduct($data);
				    redirect(base_url() . "AdminController/manageproduct");
					
		   }
		}

	

		public function editproduct($id){
			$this->isLogin();
			$data['product'] = $this->AdminModel->getProduct($id);
			$data['category'] = $this->AdminModel->getCategory();
			$this->load->view('header.php');
            $this->load->view('edit-product.php', $data);
            $this->load->view('footer.php');
		}

		public function edit_product($id){
			$this->isLogin();
			$url = base_url() . "AdminController/editproduct/$id";
			$data['title'] = $this->input->post('title');
			$data['catalogno'] = $this->input->post('catalogno');
			$data['track'] = $this->input->post('track');
			$data['description'] = $this->input->post('description');
			$data['categoryid'] = $this->input->post('categoryid');
			$data['usages'] = $this->input->post('usages');
			$data['key'] = $this->input->post('key');
			$data['bpm'] = $this->input->post('bpm');
			$data['price1'] = $this->input->post('price1');
			$data['price2'] = $this->input->post('price2');
			$data['price3'] = $this->input->post('price3');
			$data['discount'] = $this->input->post('discount');
			$data['status'] = $this->input->post('status');
			
			$oldphoto = $this->input->post('oldphoto');
			// $olddemotrack = $this->input->post('olddemotrack');

			

			if($_FILES['photo']['name'] == "" ){
				// $data['resume'] = $oldresume;
					$data['photo'] = $oldphoto;
			}else{
					$data['photo'] = str_replace(' ', '_', $_FILES['photo']['name']);
					
				   $config = array(
					'upload_path' => "./upload/Product/",
					'allowed_types' => "gif|jpg|png|jpeg",
					// 'max_size' => '2048000'
				    );
				    $this->load->library('upload', $config);
	
				
				    if(!$this->upload->do_upload('photo')){
						$error = array('error' => $this->upload->display_errors());
						echo "<script>alert('{$error['error']}');</script>";
				        echo "<script>window.location.href = '{$url}';</script>";
						die();	
					
				    }else{
					    if(file_exists('./upload/Product/' . $oldphoto)){
							unlink('./upload/Product/' . $oldphoto);
						}
						$data1 = array('upload_data' => $this->upload->data("{$data['photo']}"));
						
				
			        }
					
			
			
		    }

		

			$this->AdminModel->updateProduct($id,$data);
			redirect(base_url() . "AdminController/manageproduct");
		}

		public function manageproduct(){
			$this->isLogin();
			$data['product'] = $this->AdminModel->getAllProduct();
			$this->load->view('header');
            $this->load->view('manage-product', $data);
            $this->load->view('footer');
		}

		public function deleteproduct($id){
			$this->isLogin();
            $product = $this->AdminModel->getProduct($id);
			$productphoto = $product->photo;
			$productdemotrack = $product->demotrack;
			if(file_exists('./upload/Product/' . $productphoto)){
				unlink('./upload/Product/'.$productphoto);
			}

			if(file_exists('./upload/Product/' . $productdemotrack)){
				unlink('./upload/Product/'.$productdemotrack);
			}
			
			$this->AdminModel->deleteProduct($id);
			redirect(base_url() . "AdminController/manageproduct");
		}

		public function uploadsheet(){
			$this->isLogin();
			$data['product'] = $this->AdminModel->getAllProduct();
			$this->load->view('header');
            $this->load->view('uploadsheet', $data);
            $this->load->view('footer');
		}


		public function upload_sheet(){
			$url = base_url() . "AdminController/uploadsheet";
			$data['product_id'] = $this->input->post('product_id');
			$ex = pathinfo($_FILES['sheet']['name'], PATHINFO_EXTENSION);
			$sheet  = time() .  '' . rand(1,100) . "." . $ex;
			$data['sheetname'] = $sheet;
			
			$config = array(
				'upload_path' => "./upload/Sheet/",
				'allowed_types' => "xls|xlsx|csv",
				'file_name' => $sheet
				// 'max_size' => '2048000'
			);
			
			$this->load->library('upload', $config);
		

			if(!$this->upload->do_upload('sheet')){
				$error = array('error' => $this->upload->display_errors());
				echo "<script>alert('{$error['error']}');</script>";
				echo "<script>window.location.href = '{$url}';</script>";

			}else{
			
					$data1 = array('upload_data' => $this->upload->data());
					$this->AdminModel->uploadsheet($data);
					redirect(base_url() . "AdminController/managesheet");
			}
			
		}

		public function managesheet(){
			$this->isLogin();
			$data['sheet'] = $this->AdminModel->getallsheet();
			$this->load->view('header');
            $this->load->view('manage-sheet', $data);
            $this->load->view('footer');
		}

		public function deletesheetfile($id){
			$data['sheet'] = $this->AdminModel->getsheet($id);
			$sheetname = $data['sheet']->sheetname;
			
			if(file_exists('./upload/Sheet/'. $sheetname)){
				
				unlink('./upload/Sheet/'. $sheetname);
			}
			
			$this->AdminModel->deletesheetfile($id);
			redirect(base_url() . "AdminController/managesheet");
		}
       
		public function whitelist(){
			$this->isLogin();
			if($_SESSION['role'] == 1){
				redirect(base_url() . "AdminController/manageCategory");
			}
			$data['list'] = $this->AdminModel->getwhitelist();
			$this->load->view('header');
            $this->load->view('manage-whitelist', $data);
            $this->load->view('footer');
		}

		public function editwhitelist($id){
			$this->isLogin();
			if($_SESSION['role'] == 1){
				redirect(base_url() . "AdminController/manageCategory");
			}
			$data['status'] = $this->AdminModel->editwhitelist($id);
			
			$this->load->view('header');
            $this->load->view('edit-whitelist', $data);
            $this->load->view('footer');
		}

		public function edit_whitelist($id){
			$this->isLogin();
			if($_SESSION['role'] == 1){
				redirect(base_url() . "AdminController/manageCategory");
			}
			$data['status'] = $_POST['status'];
			$this->AdminModel->updatewhitelist($id, $data);
			redirect(base_url() . "AdminController/whitelist");
		}

		public function changestatus(){
		    $option = $_POST['option'];
			if($option == "approve"){
				$data['status'] = 0;
			}elseif($option == "disapprove"){
				$data['status'] = 1;
			}else{
				$data['status'] = 2;
			}
			// $data['status'] = 0;
			$id = $_POST['id'];
			$totalid = count($id);
			
			for($i = 0; $i < $totalid; $i++){
				$this->AdminModel->updatewhitelist($id[$i], $data);
			}
			echo 1;
		}

		public function adddemotrack(){
			$this->isLogin();
			$data['product'] = $this->AdminModel->getAllProduct();
			$this->load->view('header');
            $this->load->view('add-demotrack', $data);
            $this->load->view('footer');
		}

		public function managedemotrack(){
			$this->isLogin();
			$data['demotrack'] = $this->AdminModel->getalldemotrack();
			$this->load->view('header');
            $this->load->view('manage-demotrack', $data);
            $this->load->view('footer');
		}

		public function add_demotrack(){
			$this->isLogin();
			$data['product_id'] = $this->input->post('product_id');
			$demotrackArr = $_FILES['demotrack']['name'];
			$totaldemo = count($demotrackArr);
			for($i = 0; $i < $totaldemo; $i++){
				$ex = pathinfo($_FILES['demotrack']['name'][$i], PATHINFO_EXTENSION);
				$filename = time() . "" . rand(1,100) . "." . $ex;
				$data['demotrack'] = $filename;
				if(move_uploaded_file($_FILES['demotrack']['tmp_name'][$i], "./upload/Demotrack/" . $filename)){
					$this->AdminModel->adddemotrack($data);
				}
			}

			redirect(base_url() . "AdminController/managedemotrack");
		}

		

		public function deletedemotrack($id){
			$data['demotrack'] = $this->AdminModel->getdemotrack($id);
			$demotrack = $data['demotrack']->demotrack;
			
			if(file_exists('./upload/Demotrack/'. $demotrack)){
				
				unlink('./upload/Demotrack/'. $demotrack);
			}
			
			$this->AdminModel->deletedemotrack($id);
			redirect(base_url() . "AdminController/managedemotrack");
		}

		public function addtrack(){
			$this->isLogin();
			$data['product'] = $this->AdminModel->getAllProduct();
			$this->load->view('header');
            $this->load->view('add-track', $data);
            $this->load->view('footer');
		}

		public function add_track(){
			$this->isLogin();
			$data['product_id'] = $this->input->post('product_id');
			$trackArr = $_FILES['track']['name'];
			$totaltrack = count($trackArr);
			for($i = 0; $i < $totaltrack; $i++){
				$ex = pathinfo($_FILES['track']['name'][$i], PATHINFO_EXTENSION);
				$filename = time() . "" . rand(1,100) . "." . $ex;
				$data['trackid'] = 'TRACK' . time() . "" . rand(1,10);
				$data['track'] = $filename;
				if(move_uploaded_file($_FILES['track']['tmp_name'][$i], "./upload/Track/" . $filename)){
					$this->AdminModel->addtrack($data);
				}
			}

			redirect(base_url() . "AdminController/managetrack");
		}

		public function managetrack(){
			$this->isLogin();
			$data['track'] = $this->AdminModel->getalltrack();
			$this->load->view('header');
            $this->load->view('manage-track', $data);
            $this->load->view('footer');
		}

		public function deletetrack($id){
			
			$data['track'] = $this->AdminModel->gettrack($id);
			$track = $data['track']->track;
		
			if(file_exists('./upload/Track/'. $track)){
				
				unlink('./upload/Track/'. $track);
			}
			
			$this->AdminModel->deletetrack($id);
			redirect(base_url() . "AdminController/managetrack");
		}


		public function manageusers(){
			$data['allusers'] = $this->AdminModel->getallusers();
			$this->load->view('header');
            $this->load->view('manage-users', $data);
            $this->load->view('footer');

		}


		public function viewclient($id){
			$data['clientorder'] = $this->AdminModel->clientorderinfo($id);
			$this->load->view('header');
            $this->load->view('manage-clientorder.php', $data);
            $this->load->view('footer');
		}
       

		public function addupcomingproduct(){
			$this->isLogin();
			$data['category'] = $this->AdminModel->getCategory();
			$this->load->view('header.php');
			$this->load->view('add-upcomingproduct', $data);
			$this->load->view('footer.php');
		}

		public function add_upcomingproduct(){
			$this->isLogin();
			$url = base_url() . "AdminController/addupcomingproduct";
			$data['title'] = $this->input->post('title');
			
			$data['categoryid'] = $this->input->post('categoryid');
		
			$data['status'] = $this->input->post('status');
		
			if(isset($_FILES['photo']['name']) && $_FILES['demotrack']['name'][0] != ""){
				$photoex = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
				$extensionArr = array('png', 'jpeg', 'jpg', 'gif'); 
				if(!in_array($photoex, $extensionArr)){
					echo "<script>alert('Only Support png, jpeg, jpg format')</script>";
					// echo $url;
					echo "<script>window.location.href = '{$url}';</script>";
					die();
				}else{
					$imgname = time() . "." . $photoex;
					if(move_uploaded_file($_FILES['photo']['tmp_name'], './upload/UpcomingProduct/' . $imgname)){

					}
					$data['photo'] = $imgname;
					$demoArr = $_FILES['demotrack']['name'];
					$totaldemotrack = count($demoArr);
					for($i = 0; $i < $totaldemotrack; $i++){
						$musicex = pathinfo($_FILES['demotrack']['name'][$i], PATHINFO_EXTENSION);
						$newname[$i] = time() . rand(1,100) . "." . $musicex;
						if(move_uploaded_file($_FILES['demotrack']['tmp_name'][$i], './upload/UpcomingProduct/' . $newname[$i])){

							$fordb[] = $newname[$i];
						} 
					}

					$data['demotrack'] = implode(",", $fordb);
				
				}
			}
			
			
            $this->AdminModel->addupcomingProduct($data);
			redirect(base_url() . "AdminController/manageupcomingproduct");
			
		}

		public function manageupcomingproduct(){
			$this->isLogin();
			$data['product'] = $this->AdminModel->getallupcoming();
			$this->load->view('header');
            $this->load->view('manage-upcomingproduct', $data);
            $this->load->view('footer');
		}

		public function editupcomingproduct($id){
			$this->isLogin();
			$data['category'] = $this->AdminModel->getCategory();
			$data['product'] = $this->AdminModel->getupcomingproduct($id);
			$this->load->view('header');
            $this->load->view('edit-upcomingproduct', $data);
            $this->load->view('footer');
		}

		public function editupcomingdemo($id){
			$this->isLogin();
			$data['product'] = $this->AdminModel->getupcomingproduct($id);
			$this->load->view('header');
            $this->load->view('editupcomingdemo', $data);
            $this->load->view('footer');
		}

		public function edit_upcomingdemo($id){
			$this->isLogin();
			$olddemoStr = $this->input->post("olddemotrack");
			echo $olddemoStr;
			$demoArr = explode(",", $olddemoStr);
			
			$demotrack = [];
			if($_FILES['demotrack']['name'][0] != ""){
				$trackArr = $_FILES['demotrack']['name'];
			   $totaltrack = count($trackArr);
			  for($i = 0; $i < $totaltrack; $i++){
				$ex = pathinfo($_FILES['demotrack']['name'][$i], PATHINFO_EXTENSION);
				$filename = time() . '' . rand(1,100) . "." . $ex;
				// $data['demotrack'] = $filename;
				if(move_uploaded_file($_FILES['demotrack']['tmp_name'][$i], "./upload/UpcomingProduct/" . $filename)){
					array_push($demotrack, $filename);
				}
			  }

			  $totaldemo = count($demoArr);
			  for($j = 0; $j < $totaldemo; $j++){
				  if(file_exists('./upload/UpcomingProduct/' . $demoArr[$j])){
					  unlink('./upload/UpcomingProduct/' . $demoArr[$j]);
				  }
			  }
			  
			  $data['demotrack'] = implode(",", $demotrack);
			  $this->AdminModel->updateupcomingdemo($id, $data);

			}


			
			redirect(base_url() . "AdminController/manageupcomingproduct");
		}
		public function edit_upcomingproduct($id){
			$url = base_url() . "AdminController/editupcomingproduct/" . $id;
			$data['title'] =  $this->input->post('title');
			$data['categoryid'] = $this->input->post('categoryid');
			$oldphoto = $this->input->post('oldphoto');
			$data['status'] = $this->input->post('status');
			if($_FILES['photo']['name'] == ""){
				$data['photo'] = $oldphoto;
			}else{
				$photoex = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
				$extensionArr = array('png', 'jpeg', 'jpg', 'gif'); 
				if(!in_array($photoex, $extensionArr)){
					echo "<script>alert('Only Support png, jpeg, jpg format')</script>";
					echo "<script>window.location.href = '{$url}';</script>";
					die();
				}else{
					$photoname = time() . "." . $photoex;

					if(move_uploaded_file($_FILES['photo']['tmp_name'], './upload/UpcomingProduct/' . $photoname)){
						$data['photo'] = $photoname;
						unlink('./upload/UpcomingProduct/' . $oldphoto);
					}
				}
			}

		    $this->AdminModel->updateupcomingproduct($id, $data);
			redirect(base_url() . "AdminController/manageupcomingproduct");
		}
		public function deleteupcomingproduct($id){
			$this->isLogin();
            $product = $this->AdminModel->getupcomingproduct($id);
			$productphoto = $product->photo;
			$productdemotrack = $product->demotrack;
		
			$demoArr = explode(",", $productdemotrack);
			if(file_exists('./upload/UpcomingProduct/' . $productphoto)){
				unlink('./upload/UpcomingProduct/'.$productphoto);
			}
			$totalArr = count($demoArr);
            for($i = 0; $i < $totalArr; $i++){
				if(file_exists('./upload/UpcomingProduct/' . $demoArr[$i])){
					unlink('./upload/UpcomingProduct/'. $demoArr[$i]);
				}
			} 
			
			
			$this->AdminModel->deleteupcomingproduct($id);
			redirect(base_url() . "AdminController/manageupcomingproduct");
		}

		public function createlicense(){
			$this->isLogin();
			$this->load->view('header');
            $this->load->view('createlicense');
            $this->load->view('footer');
		}

		public function create_license(){
			$this->isLogin();
			$data['licenseno'] = $this->input->post('licenseno');
			$this->AdminModel->addlicense($data);
			redirect(base_url() . "AdminController/managelicense");
		}

		public function managelicense(){
			$this->isLogin();
			$data['license'] = $this->AdminModel->getalllicense();
			$this->load->view('header');
            $this->load->view('managelicense', $data);
            $this->load->view('footer');

		}

		public function editlicense($id){
			$this->isLogin();
			$data['license'] = $this->AdminModel->getlicense($id);
			
			$this->load->view('header');
            $this->load->view('editlicense', $data);
            $this->load->view('footer');
		}

		public function edit_license($id){
			$this->isLogin();
			$data['licenseno'] = $this->input->post('licenseno');
			$this->AdminModel->editlicense($id, $data);
			redirect(base_url() . "AdminController/managelicense");
		}
		
		public function deletelicense($id){
			$this->AdminModel->deletelicense($id);
			redirect(base_url() . "AdminController/managelicense");

		}

		public function createstaff(){
			$this->isLogin();
			$this->load->view('header');
            $this->load->view('add-staff');
            $this->load->view('footer');
		}

		public function add_staff(){
			$this->isLogin();
			$url = base_url() . "AdminController/createstaff";
			$data['name'] = $this->input->post('name');
			$data['email'] = $this->input->post('email');
			$data['mobile'] = $this->input->post('mobile');
			$data['password'] = $this->input->post('password');
			$data['role'] = 1;
			
			$isValid = $this->AdminModel->checkemail($data['email']);
			if(isset($isValid)){
				echo "<script>alert('Email Already Exists');</script>";
				echo "<script>window.location.href = '{$url}';</script>";
				die();

			}else{
				 $this->AdminModel->insertuser($data);
				 redirect(base_url() . "AdminController/managestaff");
			}
		}

		public function managestaff(){
			$this->isLogin();
			$id  = $_SESSION['id'];
			$data['staff'] = $this->AdminModel->getaccount($id);
			$this->load->view('header');
            $this->load->view('manage-staff', $data);
            $this->load->view('footer');
		}

		public function editstaff($id){
			$this->isLogin();
			$data['staff'] = $this->AdminModel->getstaffacc($id);
			$this->load->view('header');
			$this->load->view('edit-staff', $data);
			$this->load->view('footer');
		
		}

		public function edit_staff($id){
			$url = base_url() . "AdminController/editstaff/" . $id;
			$data['name'] = $this->input->post('name');
			$data['email'] = $this->input->post('email');
			$data['mobile'] = $this->input->post('mobile');
			$data['password'] = $this->input->post('password');
			$isValid = $this->AdminModel->checkemail($data['email']);
			
			
			if(isset($isValid)){
				if($id == $isValid->id){
					$this->AdminModel->updateStaff($id, $data);
				}else{
					echo "<script>alert('Email Already Exists');</script>";
					echo "<script>window.location.href = '{$url}';</script>";
					die();
				}
			}else{
				$this->AdminModel->updateStaff($id, $data);
			}

			redirect(base_url() . "AdminController/managestaff");

		}


		public function deletestaff($id){
			$this->AdminModel->deletestaff($id);
			redirect(base_url() . "AdminController/managestaff");
		}

		public function allwhitelist(){
			$this->isLogin();
			if($_SESSION['role'] == 1){
				redirect(base_url() . "AdminController/manageCategory");
			}
			$data['list'] = $this->AdminModel->getAllwhitelist();
			$this->load->view('header');
            $this->load->view('all-whitelist', $data);
            $this->load->view('footer');
		}

		public function manageorder(){
			$data['clientorder'] = $this->AdminModel->allorders();
			$this->load->view('header');
			$this->load->view('manage-clientorder.php', $data);
			$this->load->view('footer');
		}
	

	}

?>
